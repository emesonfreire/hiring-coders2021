//crie um algorítimo que receba  três notas de um aluno, calcule sua média e
//mostre as seguintes mensagensn de acordo com cada situação:
//-se a media for igual ou maior que 7-aprovado
//se a media for maior  e  igual a cinco e menor que 7 - recuperação
//se a media for menor que 5-reprovadp.

function calculaMedia(nota1, nota2, nota3){
    let media = (nota1+nota2+nota3)/3
    if (media >=7){
        return"aprovado"
    }
    if(media >=5 && media <7){
        return "recuperação "
    }
    if(media < 5 ){
        return "reprovado"
    }
}