const livros = [
    { 
        id: 1,
        nome: "Digital Minimalism",
        autor:"Cal Newport",
        categoria: "Produtividade e estilo de vida",
        paginas: 254,
        recomenda: false,
        leu: false
    },
    { 
        id: 2,
        nome: "O Genocídio do negro brasileiro",
        autor:"Abdias do Nascimento",
        categoria: "História brasileira",
        paginas: 254,
        recomenda: false,
        leu: false
    },
    { 
        id: 3,
        nome: "As veias abertas da américa latina",
        autor:"Eduardo galeano",
        categoria: "Américas",
        paginas: 400,
        recomenda: false,
        leu: false
    },
    { 
        id: 4,
        nome: "Algoritmos para viver",
        autor:"Brian Christian",
        categoria: "Tecnologia",
        paginas: 412,
        recomenda: true,
        leu: true
    },
    { 
        id: 5,
        nome: "Thinking, fast and slow",
        autor:"Daniel Kahneman",
        categoria: "Estilo de vida",
        paginas: 418,
        recomenda: true,
        leu: true
    },
    { 
        id: 6,
        nome: "Padrões Javascript",
        autor:"Stoyan Stefanov",
        categoria: "Tecnologia",
        paginas: 231,
        recomenda: true,
        leu: true
    }
]

module.exports = livros