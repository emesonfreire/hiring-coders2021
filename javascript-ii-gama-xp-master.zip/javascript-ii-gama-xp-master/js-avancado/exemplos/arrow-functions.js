// function

function soma(a,b) {
    return a + b
}

console.log(soma(3,5)) //8

//arrow function

const soma = (num1, num2) => num1 + num2

const sayHello = name => `Hello ${name}`

console.log(sayHello('Mari'))