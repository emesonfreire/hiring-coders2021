function calculaIdade(idade) {
    return idade >= 18? 'maior de idade' : 'menor de didade'
}
console.log(calculaIdade(15))