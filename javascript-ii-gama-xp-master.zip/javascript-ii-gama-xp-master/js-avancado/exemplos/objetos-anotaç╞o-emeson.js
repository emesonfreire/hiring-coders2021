
//objeto pessoa

const pessoa = {
    nome:"Emeson",
    idade:26,
    cidade:"são bernardo do campo",
}
//acessando dados do objeto pessoa
//notação de ponto

//'Emeson'
console.log(pessoa.nome)

//notação de colchetes [' ']
console.log( pessoa['idade'])

//como acessar informação no obejto pelo metodo destructuri( desestruturar objetos)


const {nome,idade,cidade} = pessoa
console.log(nome)
console.log(idade)
console.log(cidade)

//array de objetos

const filmes =[
    {
        id:"01",
        titulo:"guerra do amanhã",
        descricao:"guerra",
        duracao:60,
    },
    {
        id:"02",
        titulo:"misterbean",
        descricao:"besteirol",
        duracao:90,
    },
    {
        id:"03",
        titulo:"o pimentinha",
        descricao:"comédia",
        duracao:130,
    }
]

const [{id,titulo,descricao,duracao} ]= filmes
filmes.map(filme=> console.log(filme.descricao))