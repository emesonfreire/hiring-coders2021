"Simara é"
let role = "transformadora"

console.log(`Simara é ${role}`)

console.log("Simara é" + " " + role)