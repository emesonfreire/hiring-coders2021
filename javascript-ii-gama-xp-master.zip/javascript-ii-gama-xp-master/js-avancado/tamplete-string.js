let role ="d+mais"
console.log(`Emeson é ${role}`)
